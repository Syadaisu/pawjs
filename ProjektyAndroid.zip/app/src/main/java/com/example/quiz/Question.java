package com.example.quiz;

public class Question {
    private int questionId;
    private boolean trueAnwser;

    public Question(int questionId,boolean trueAnwser) {
        this.questionId=questionId;
        this.trueAnwser=trueAnwser;
    }

    public boolean isTrueAnswer(){
        if(this.trueAnwser)
            return true;
        return false;
    }

    public int getQuestionId(){
        return this.questionId;
    }

}
