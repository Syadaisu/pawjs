package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.Nullable;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;


import java.security.Key;

public class MainActivity extends AppCompatActivity {
    private static final String KEY_CURRENT_INDEX = "currentIndex";
    public static final String KEY_EXTRA_ANSWER = "qwertyuiop";
    private static final int REQUEST_CODE_PROMPT=0;
    private Button trueButton;
    private Button falseButton;
    private Button nextButton;
    private Button promptButton;
    private TextView questionTextView;
    private TextView answersCountTextView;
    private int currentIndex=0;
    private int correctAnswersCount=0;
    private int incorrectAnswersCount=0;
    private boolean answerWasShown = false;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("QuizTest","Wywolana zostala metoda: onSaveInstanceState");
        outState.putInt(KEY_CURRENT_INDEX, currentIndex);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("QuizTest","Wywolano onCreate");
        setContentView(R.layout.activity_main);

        if(savedInstanceState != null){
            currentIndex = savedInstanceState.getInt(KEY_CURRENT_INDEX);
        }
        trueButton = findViewById(R.id.true_button);
        falseButton = findViewById(R.id.false_button);
        nextButton = findViewById(R.id.next_button);
        promptButton=findViewById(R.id.prompt_button);
        questionTextView = findViewById(R.id.question_text_view);
        answersCountTextView = findViewById(R.id.answers_count);

        trueButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                checkAnswerCorrectness(true);
            }
        });
        falseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                checkAnswerCorrectness(false);
            }
        });
        nextButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                currentIndex = (currentIndex+1)% questions.length;
                answerWasShown = false;
                setNextQuestion();
                if(currentIndex+1==questions.length){
                    DisplayResults();
                }
            }

        });
        promptButton.setOnClickListener((v) ->{
            Intent intent = new Intent(MainActivity.this,PromptActivity.class);
            boolean correctAnswer = questions[currentIndex].isTrueAnswer();
            intent.putExtra(KEY_EXTRA_ANSWER, correctAnswer);
            startActivityForResult(intent, REQUEST_CODE_PROMPT);
        });

    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.d("QuizTest","Wywolano onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("QuizTest","Wywolano onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.d("QuizTest","Wywolano onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("QuizTest","Wywolano onDestroy");
    }


    private Question[] questions=new Question[]{
            new Question(R.string.q_activity,true),
            new Question(R.string.q_samsung,true),
            new Question(R.string.q_polska,false),
            new Question(R.string.q_rdm,true),
            new Question(R.string.q_gta,true)
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode,data);
        if(resultCode != RESULT_OK){return;}
        if(requestCode == REQUEST_CODE_PROMPT){
            if(data ==null ){return;}
            answerWasShown = data.getBooleanExtra(PromptActivity.KEY_EXTRA_ANSWER_SHOWN, false);
        }
    }

    private void checkAnswerCorrectness(boolean userAnswer){
        boolean correctAnswer=questions[currentIndex].isTrueAnswer();
        int resultMessageId=0;
        if (answerWasShown){
            resultMessageId = R.string.answer_was_shown;
        }
        if(userAnswer==correctAnswer){
            resultMessageId=R.string.correct_answer;
            correctAnswersCount++;
        }
        else {
            resultMessageId = R.string.incorrect_answer;
            incorrectAnswersCount++;
        }
        Toast.makeText(this,resultMessageId,Toast.LENGTH_SHORT).show();
    }

    private void setNextQuestion(){
        questionTextView.setText(questions[currentIndex].getQuestionId());
    }

    private void DisplayResults(){
        answersCountTextView.setText("Poprawnych odpowiedzi:"+correctAnswersCount+"\nNiepoprawnych:"+incorrectAnswersCount);
    }

}